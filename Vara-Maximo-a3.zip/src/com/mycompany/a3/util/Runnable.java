package com.mycompany.a3.util;

public interface Runnable {
	public void run();
}
