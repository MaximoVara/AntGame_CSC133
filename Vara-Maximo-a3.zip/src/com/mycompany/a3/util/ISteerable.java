package com.mycompany.a3.util;

public interface ISteerable {
	public void setHeading(int compassAngle);
	public void turnRight();
	public void turnLeft();
}
